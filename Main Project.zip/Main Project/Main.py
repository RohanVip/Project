import sqlite3
import logging
from validate_email import validate_email
import re
import os
import hashlib
import datetime
from flask import Flask, render_template, request, redirect, session, jsonify, url_for, flash
from flask_wtf.csrf import generate_csrf
from filters import format_date


app = Flask(__name__, static_url_path='/static')
app.secret_key = "secret_key"


# Connect to the database
conn = sqlite3.connect('test.db', timeout=30)

c = conn.cursor()


# Create the users table if it doesn't already exist
c.execute('''
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY,
        username TEXT NOT NULL UNIQUE,
        email TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL
    )
''')
# Create the departments table if it doesn't already exist
c.execute('''
CREATE TABLE IF NOT EXISTS departments (
    department_id INTEGER PRIMARY KEY,
    department_name TEXT UNIQUE
)
''')

# Create the add employee table if it doesn't already exist
c.execute('''
    CREATE TABLE IF NOT EXISTS employees (
    employee_id INTEGER PRIMARY KEY,
    first_name TEXT,
    last_name TEXT,
    email TEXT,
    mobile_number TEXT,
    password TEXT,
    city TEXT,
    address TEXT,
    dob TEXT,
    date_of_joining TEXT,
    salary REAL,
    department_id INTEGER,
    FOREIGN KEY (department_id) REFERENCES departments(department_id)
    )
''')

# Create the "leave_requests" table if it doesn't already exist
c.execute('''CREATE TABLE IF NOT EXISTS leave_requests
             (id INTEGER PRIMARY KEY AUTOINCREMENT, 
              employee_name TEXT,
              start_date TEXT,
              end_date TEXT,
              reason TEXT,
              status TEXT DEFAULT "Pending")''')


# Create the "salary" table if it doesn't already exist
c.execute('''CREATE TABLE IF NOT EXISTS salary (
    salary_id INTEGER PRIMARY KEY,
    department_name TEXT,
    employee_name TEXT,
    salary INTEGER,
    date DATE,
    FOREIGN KEY (department_name) REFERENCES departments (department_name)
)
''')


# Create the "leaves" table with an auto-incrementing primary key
c.execute('''
    CREATE TABLE IF NOT EXISTS leaves (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        days INTEGER
    )
''')

# Commit the changes and close the connection
conn.commit()
conn.close()

ADMIN_USERNAME = 'admin'
ADMIN_PASSWORD = 'admin'




@app.route('/')
def index():
    return render_template('index.html')

# Define the format_date filter
@app.template_filter('format_date')
def format_date(value, format='%d/%m/%Y'):
    if isinstance(value, str):
        value = datetime.datetime.strptime(value, '%Y-%m-%d')
    return value.strftime(format)

# Email validation function
def validate_email(email):
    # Regex pattern for valid email address
    pattern = r"(^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$)"
    match = re.match(pattern, email)
    if match:
        # Check if the email address ends with .com.com
        if email.endswith('.com.com'):
            return False
        else:
            return True
    else:
        return False

@app.route('/admin-login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        if username == ADMIN_USERNAME and password == ADMIN_PASSWORD:
            return redirect(url_for('admin_dashboard'))
        else:
            error = 'Invalid username or password'
            return render_template('admin/admin-login.html', error=error)
    else:
        return render_template('admin/admin-login.html')


@app.route('/admin-dashboard')
def admin_dashboard():
    # Connect to the database
    conn = sqlite3.connect('test.db')
    c = conn.cursor()

    # Get the total number of departments
    c.execute('SELECT COUNT(*) FROM departments')
    num_departments = c.fetchone()[0]

    # Get the total number of employees
    c.execute('SELECT COUNT(*) FROM employees')
    num_employees = c.fetchone()[0]

    # Get the total number of types of leaves
    c.execute('SELECT COUNT(DISTINCT name) FROM leaves')
    num_leave_types = c.fetchone()[0]

    # Close the database connection
    conn.close()

    # Render the admin dashboard template with the number of departments, employees, and leave types
    return render_template('admin/admin-dashboard.html', num_departments=num_departments, num_employees=num_employees, num_leave_types=num_leave_types)


# Route For Add Department
@app.route('/add-department', methods=['GET', 'POST'])
def add_department():
    if request.method == 'POST':
        # Get the department name from the form submission
        department_name = request.form['department_name']
        if not department_name:
            return jsonify({'error': 'Department name is required'})

        # Add the new department to the database
        conn = sqlite3.connect('test.db')
        c = conn.cursor()
        try:
            c.execute('CREATE TABLE IF NOT EXISTS departments (department_id INTEGER PRIMARY KEY, department_name TEXT UNIQUE)')
            c.execute('INSERT INTO departments (department_name) VALUES (?)', (department_name,))
            # Create a separate table for the department to store employee information
            c.execute('CREATE TABLE IF NOT EXISTS employees_{} (employee_id INTEGER PRIMARY KEY, employee_name TEXT)'.format(department_name.lower()))
            conn.commit()
            return jsonify({'success': 'Department added successfully'})
        except sqlite3.IntegrityError:
            return jsonify({'error': 'Department already exists'})
        finally:
            conn.close()
    else:
        # Render the add department form template
        return render_template('admin/add_department.html')



# Route For Manage Department
@app.route('/manage-departments', methods=['GET', 'POST'])
def manage_departments():
    if request.method == 'POST':
        # Get the action and department ID from the form submission
        action = request.form['action']
        department_id = request.form['department_id']

        # Handle update or delete action
        if action == 'update':
            # Get the new department name from the form submission
            new_department_name = request.form['new_department_name']

            # Update the department in the database
            conn = sqlite3.connect('test.db')
            c = conn.cursor()
            c.execute('UPDATE departments SET department_name = ? WHERE department_id = ?', (new_department_name, department_id))
            conn.commit()
            conn.close()

            # Return a success message
            return "Department updated successfully!"

        elif action == 'delete':
            # Delete the department from the database
            conn = sqlite3.connect('test.db')
            c = conn.cursor()
            c.execute('DELETE FROM departments WHERE department_id = ?', (department_id,))
            conn.commit()

            # Update department IDs in database
            c.execute('SELECT department_id FROM departments ORDER BY department_id ASC')
            rows = c.fetchall()

            for i, row in enumerate(rows):
                new_id = i + 1
                if row[0] != new_id:
                    c.execute('UPDATE departments SET department_id=? WHERE department_id=?', (new_id, row[0]))

            conn.commit()
            conn.close()

            # Return success message
            return "Department deleted successfully!"

        else:
            # Invalid action
            return "Invalid action."

    else:
        # Fetch list of departments from database
        conn = sqlite3.connect('test.db')
        c = conn.cursor()
        c.execute('SELECT * FROM departments')
        departments = c.fetchall()
        conn.close()

        # Render the manage departments template with the list of departments
        return render_template('admin/manage_departments.html', departments=departments)



# Route For Add Employees
@app.route('/add-employee', methods=['GET', 'POST'])
def add_employee():
    if request.method == 'POST':
        # Get the employee information from the form submission
        first_name = request.form['first_name']
        last_name = request.form['last_name']
        email = request.form['email']
        mobile_number = request.form['mobile_number']
        city = request.form['city']
        address = request.form['address']
        dob = request.form['dob']
        date_of_joining = request.form['date_of_joining']
        salary = request.form['salary']
        department_id = request.form['department_id']
        password = request.form['password']

        # Insert the employee into the database with the appropriate department ID and password
        conn = sqlite3.connect('test.db')
        c = conn.cursor()
        c.execute('''
            INSERT INTO employees (first_name, last_name, email, mobile_number, city, address, dob, date_of_joining, salary, department_id, password)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (first_name, last_name, email, mobile_number, city, address, dob, date_of_joining, salary, department_id, password))
        conn.commit()

        # Get the ID of the newly inserted employee
        employee_id = c.lastrowid

        conn.close()

        # Return a success message
        return "Employee added successfully with ID " + str(employee_id)

    else:
        # Fetch list of departments from database
        conn = sqlite3.connect('test.db')
        c = conn.cursor()
        c.execute('SELECT * FROM departments')
        departments = c.fetchall()
        conn.close()

        # Render the add employee template with the list of departments
        return render_template('admin/add_employee.html', departments=departments)



# Route For Manage All Employees
@app.route('/manage-employees', methods=['GET', 'POST'])
def manage_employees():
    if request.method == 'POST':
        # Get the action and employee ID from the form submission
        action = request.form['action']
        employee_id = request.form['employee_id']

        if action == 'update':
            # Fetch employee details from database
            conn = sqlite3.connect('test.db')
            c = conn.cursor()
            c.execute('SELECT * FROM employees WHERE employee_id = ?', (employee_id,))
            employee = c.fetchone()
            c.execute('SELECT * FROM departments')
            departments = c.fetchall()
            conn.close()

            # Render the update employee form with the employee details and list of departments
            return render_template('admin/update-employee.html', employee=employee, departments=departments)

        elif action == 'submit_update':
            # Get the employee details from the form submission
            first_name = request.form['first_name']
            last_name = request.form['last_name']
            email = request.form['email']
            mobile_number = request.form['mobile_number']
            password = request.form['password']
            city = request.form['city']
            address = request.form['address']
            dob = request.form['dob']
            date_of_joining = request.form['date_of_joining']
            salary = request.form['salary']
            department_id = request.form['department_id']

            # Update the employee in the database
            conn = sqlite3.connect('test.db')
            c = conn.cursor()
            c.execute('UPDATE employees SET first_name=?, last_name=?, email=?, mobile_number=?, password=?, city=?, address=?, dob=?, date_of_joining=?, salary=?, department_id=? WHERE employee_id=?', (first_name, last_name, email, mobile_number, password, city, address, dob, date_of_joining, salary, department_id, employee_id))
            conn.commit()
            conn.close()

            # Redirect to the manage employees page
            return redirect(url_for('manage_employees'))

        elif action == 'delete':
            # Delete the employee from the database
            conn = sqlite3.connect('test.db')
            c = conn.cursor()
            c.execute('DELETE FROM employees WHERE employee_id = ?', (employee_id,))
            conn.commit()
            conn.close()

            # Return success message
            return jsonify({'success': 'Employee Deleted Successfully'})
            return redirect(url_for('manage_employees'))

        
        elif action == 'view':
            # Fetch employee details from database
            conn = sqlite3.connect('test.db')
            c = conn.cursor()
            c.execute('SELECT * FROM employees WHERE employee_id = ?', (employee_id,))
            employee = c.fetchone()
            c.execute('SELECT department_name FROM departments WHERE department_id = ?', (employee[11],))
            department = c.fetchone()[0]
            conn.close()

            # Render the view employee page with the employee details
            return render_template('admin/view-employee.html', employee=employee, department=department)

        else:
            # Invalid action
            flash('Invalid action')
            return redirect(url_for('manage_employees'))

    else:
        # Fetch list of employees and department names from database
        conn = sqlite3.connect('test.db')
        c = conn.cursor()
        c.execute('SELECT employees.employee_id, employees.first_name, employees.last_name, employees.salary, departments.department_name FROM employees JOIN departments ON employees.department_id = departments.department_id')
        employees = c.fetchall()
        conn.close()

        # Render the manage employees template with the list of employees
        return render_template('admin/manage_employees.html', employees=employees)





# Route For Leave Requests
@app.route('/leave-requests')
def leave_requests():
    # Connect to the database
    conn = sqlite3.connect('test.db')
    c = conn.cursor()

    # Retrieve the leave requests from the database
    c.execute('SELECT employee_name, start_date, end_date, reason FROM leave_requests')
    rows = c.fetchall()

    # Close the database connection
    conn.close()

    # Render the template with the leave request data
    return render_template('admin/leave-requests.html', leave_requests=rows)






# Route For Employee Login-Client Side
@app.route('/employee-login', methods=['GET', 'POST'])
def employee_login():
    if request.method == 'POST':
        # Get the user's login credentials from the form submission
        username = request.form['username']
        password = request.form['password']

        # Query the database to find a matching employee
        conn = sqlite3.connect('test.db')
        c = conn.cursor()
        c.execute('SELECT * FROM employees WHERE (email=? OR mobile_number=?) AND password=?', (username, username, password))
        employee = c.fetchone()
        conn.close()

        if employee:
            # If the employee is found, set their ID in the session and redirect to the employee dashboard
            session['employee_id'] = employee[0]
            return redirect(url_for('employee_dashboard'))
        else:
            # If the employee is not found, show an error message
            error = "Invalid username or password. Please try again."
            return render_template('employee/login.html', error=error)

    else:
        # Render the employee login template
        return render_template('employee/login.html')
    

# Route For Employee Dashboard-Client Side
@app.route('/employee-dashboard')
def employee_dashboard():
    # Check if the user is logged in
    if 'employee_id' in session:
        # Retrieve the employee's information from the database
        employee_id = session['employee_id']
        conn = sqlite3.connect('test.db')
        c = conn.cursor()
        c.execute('SELECT first_name, last_name, email FROM employees WHERE employee_id=?', (employee_id,))
        employee = c.fetchone()

        # Use Gravatar to get the default avatar for the employee's email
        email_hash = hashlib.md5(employee[2].lower().encode()).hexdigest()
        avatar_url = f"https://www.gravatar.com/avatar/{email_hash}?d=identicon"

        # Retrieve all leaves from the database
        c.execute('SELECT name, days FROM leaves')
        leaves = c.fetchall()

        conn.close()

        # Render the employee dashboard template with the employee's information and leaves
        return render_template('employee/employee-dashboard.html', employee=employee, avatar_url=avatar_url, leaves=leaves)
    else:
        # Redirect the user to the employee login page
        return redirect(url_for('employee/login'))





# Route For Employee Profile-Client Side
@app.route('/employee-profile')
def employee_profile():
    # Check if the user is logged in
    if 'employee_id' in session:
        # Retrieve the employee's information from the database
        employee_id = session['employee_id']
        conn = sqlite3.connect('test.db')
        c = conn.cursor()
        c.execute('''
            SELECT employees.*, departments.department_name, departments.department_id
            FROM employees
            JOIN departments ON employees.department_id = departments.department_id
            WHERE employee_id=?
        ''', (employee_id,))
        employee = c.fetchone()
        conn.close()

        # Render the employee profile template with the employee's information
        return render_template('employee/employee-profile.html', employee=employee)
    else:
        # Redirect the user to the employee login page
        return redirect(url_for('employee/login'))



# Route For Apply Leave-Client Side
@app.route('/apply-leave', methods=['GET', 'POST'])
def apply_leave():
    # Check if the user is logged in
    if 'employee_id' not in session:
        # Redirect the user to the employee login page
        return redirect(url_for('employee/login'))

    # Get the logged-in employee's information from the database
    employee_id = session['employee_id']
    conn = sqlite3.connect('test.db')
    c = conn.cursor()
    c.execute('''
        SELECT first_name
        FROM employees
        WHERE employee_id=?
    ''', (employee_id,))
    employee_name = c.fetchone()[0]
    conn.close()

    # Handle form submission
    if request.method == 'POST':
        # Retrieve form data
        start_date = request.form.get('start_date')
        end_date = request.form.get('end_date')
        reason = request.form.get('reason')

        # Validate form data
        if not start_date or not end_date or not reason:
            flash('Please fill out all fields.')
        elif start_date > end_date:
            flash('Start date must be before end date.')
        else:
            # Insert leave request into the database
            conn = sqlite3.connect('test.db')
            c = conn.cursor()
            c.execute('''
                INSERT INTO leave_requests (employee_name, start_date, end_date, reason, status)
                VALUES (?, ?, ?, ?, ?)
            ''', (employee_name, start_date, end_date, reason, "pending"))


            conn.commit()
            conn.close()

            flash('Leave request submitted successfully.')
            return jsonify({'success': True, 'message': 'Leave request submitted successfully.'})


    # Render the apply leave template
    return render_template('employee/apply-leave.html', employee_name=employee_name)





# Route for Leave History-Client Side
@app.route('/leave-history')
def leave_history():
    # Check if the user is logged in
    if 'employee_id' not in session:
        # Redirect the user to the employee login page
        return redirect(url_for('employee/login'))

    # Get the logged-in employee's information from the database
    employee_id = session['employee_id']
    conn = sqlite3.connect('test.db')
    c = conn.cursor()
    c.execute('''
        SELECT first_name
        FROM employees
        WHERE employee_id=?
    ''', (employee_id,))
    employee_name = c.fetchone()[0]

    # Get the employee's leave requests from the database
    c.execute('''
        SELECT start_date, end_date, status, reason
        FROM leave_requests
        WHERE employee_name=?
        ORDER BY start_date DESC
    ''', (employee_name,))
    leave_requests = c.fetchall()

    conn.close()

    # Render the leave history template
    return render_template('employee/leave-history.html', employee_name=employee_name, leave_requests=leave_requests)



# Route for Sign Out Employee
@app.route('/sign-out')
def sign_out():
    # Clear the employee_id from the session
    session.pop('employee_id', None)

    # Redirect the user to the home page
    return redirect(url_for('index'))




# Route For Add Salary To Employees
@app.route('/add-salary', methods=['GET', 'POST'])
def add_salary():
    if request.method == 'POST':
        # Get the form data
        department_id = request.form['department']
        employee_id = request.form['employee']
        salary = request.form['salary']
        date = request.form['date']

        # Insert the salary details into the database
        conn = sqlite3.connect('test.db')
        c = conn.cursor()
        c.execute('INSERT INTO salary (department_name, employee_name, salary, date) SELECT departments.department_name, employees.first_name || " " || employees.last_name, ?, ? FROM employees JOIN departments ON employees.department_id = departments.department_id WHERE employees.employee_id = ?', (salary, date, employee_id))
        conn.commit()
        conn.close()

        # Return success message
        flash('Salary added successfully!', 'success')
        return redirect(url_for('add_salary'))

    else:
        # Fetch list of departments and employees from database
        conn = sqlite3.connect('test.db')
        c = conn.cursor()
        c.execute('SELECT * FROM departments')
        departments = c.fetchall()

        department_id = request.args.get('department_id')
        if department_id:
            c.execute('SELECT employees.employee_id, employees.first_name, employees.last_name FROM employees WHERE employees.department_id = ?', (department_id,))
        else:
            c.execute('SELECT employees.employee_id, employees.first_name, employees.last_name FROM employees')

        employees = c.fetchall()
        conn.close()

        # Render the add salary template with departments and employees
        return render_template('admin/add_salary.html', departments=departments, employees=employees)

# Route For Find Employees list by Department ID
@app.route('/get-employees/<int:department_id>')
def get_employees(department_id):
    # Fetch list of employees for the specified department from database
    conn = sqlite3.connect('test.db')
    c = conn.cursor()
    c.execute('SELECT employee_id, first_name, last_name FROM employees WHERE department_id = ?', (department_id,))
    employees = c.fetchall()
    conn.close()

    # Return the list of employees as a JSON response
    return jsonify(employees)




# Route For Check Salary
@app.route('/check-salary')
def check_salary():
    # Check if the user is logged in
    if 'employee_id' not in session:
        # Redirect the user to the employee login page
        return redirect(url_for('employee/login'))

    # Get the logged-in employee's information from the database
    employee_id = session['employee_id']
    conn = sqlite3.connect('test.db')
    c = conn.cursor()
    c.execute('''
        SELECT first_name, last_name
        FROM employees
        WHERE employee_id=?
    ''', (employee_id,))
    employee_name = ' '.join(c.fetchone())

    # Query the database for all the employee's salaries
    c.execute('''
        SELECT department_name, salary, date
        FROM salary
        WHERE employee_name=?
    ''', (employee_name,))
    salaries = c.fetchall()

    # Render the check salary page with the employee's name and all salaries
    return render_template('employee/check-salary.html', employee_name=employee_name, salaries=salaries)













# Add leave route
@app.route('/add-leave', methods=['GET', 'POST'])
def add_leave():
    if request.method == 'POST':
        # Handle form submission and add new leave to database
        name = request.form['name']
        days = request.form['days']
        conn = sqlite3.connect('test.db')
        c = conn.cursor()
        c.execute('INSERT INTO leaves (name, days) VALUES (?, ?)', (name, days))
        conn.commit()
        conn.close()
        return "Leave added successfully!"
    else:
        # Render the add leave form template
        return render_template('admin/add_leave.html')




# Route For Manage Leave
@app.route('/manage-leave', methods=['GET', 'POST'])
def manage_leave():
    if request.method == 'POST':
        # Get the action and leave ID from the form submission
        action = request.form['action']
        leave_id = request.form['leave_id']

        if action == 'edit':
            # Update leave name and days in database
            name = request.form['name']
            days = request.form['days']
            conn = sqlite3.connect('test.db')
            c = conn.cursor()
            c.execute('UPDATE leaves SET name = ?, days = ? WHERE id = ?', (name, days, leave_id))
            conn.commit()
            conn.close()

            # Return success message
            flash('Leave updated successfully!', 'success')
            return redirect(url_for('manage_leave'))

        elif action == 'delete':
            # Delete the leave from the database
            conn = sqlite3.connect('test.db')
            c = conn.cursor()

            # Check if the leave exists in the table
            c.execute('SELECT * FROM leaves WHERE id = ?', (leave_id,))
            leave = c.fetchone()
            if not leave:
                # Leave not found, return error message
                flash('Leave not found.', 'error')
                conn.close()
                return redirect(url_for('manage_leave'))

            # Execute delete query
            c.execute('DELETE FROM leaves WHERE id = ?', (leave_id,))
            conn.commit()
            conn.close()

            # Return success message
            flash('Leave deleted successfully!', 'success')
            return redirect(url_for('manage_leave'))

        else:
            # Invalid action
            flash('Invalid action.', 'error')
            return redirect(url_for('manage_leave'))

    else:
        # Fetch list of leaves from database
        conn = sqlite3.connect('test.db')
        c = conn.cursor()
        c.execute('SELECT * FROM leaves')
        leaves = c.fetchall()
        conn.close()

        # Render the manage leave template with the list of leaves
        return render_template('admin/manage_leave.html', leaves=leaves)



# Route For New Pending Leaves Requests
@app.route('/new-requests', methods=['GET', 'POST'])
def new_request():
    # Handle form submission
    if request.method == 'POST':
        # Retrieve form data
        request_id = request.form.get('request_id')
        status = request.form.get('new_status')

        # Update the status of the leave request in the database
        conn = sqlite3.connect('test.db')
        c = conn.cursor()
        c.execute('''
            UPDATE leave_requests
            SET status=?
            WHERE id=?
        ''', (status, request_id))

        conn.commit()
        conn.close()

        flash('Leave request status updated successfully.')

    # Retrieve all leave requests from the database
    conn = sqlite3.connect('test.db')
    c = conn.cursor()
    c.execute('''
        SELECT id, employee_name, start_date, end_date, reason, status
        FROM leave_requests
    ''')
    requests = c.fetchall()
    conn.close()

    # Filter out accepted and rejected leave requests
    requests = [request for request in requests if request[5] == 'pending']

    # Render the new requests template
    return render_template('admin/new_requests.html', requests=requests)



# Route For Accepted Leaves List
@app.route('/approved-requests')
def approved_requests():
    # Connect to the database
    conn = sqlite3.connect('test.db')
    c = conn.cursor()

    # Retrieve all approved leave requests from the "leave_requests" table
    c.execute('SELECT * FROM leave_requests WHERE status="accepted"')
    approved_requests = c.fetchall()

    # Close the database connection
    conn.close()

    # Render the approved requests in an HTML table
    return render_template('admin/approved_requests.html', requests=approved_requests)


# Route For Rejected Leaves List
@app.route('/rejected-requests')
def rejected_requests():
    # Connect to the database
    conn = sqlite3.connect('test.db')
    c = conn.cursor()

    # Retrieve all approved leave requests from the "leave_requests" table
    c.execute('SELECT * FROM leave_requests WHERE status="rejected"')
    rejected_requests = c.fetchall()

    # Close the database connection
    conn.close()

    # Render the approved requests in an HTML table
    return render_template('admin/rejected_requests.html', requests=rejected_requests)




# Route For All Leave Requests
@app.route('/all-requests', methods=['GET', 'POST'])
def all_requests():
    # Connect to the database
    conn = sqlite3.connect('test.db')
    c = conn.cursor()

    if request.method == 'POST':
        # Get the ID of the request to delete from the form data
        request_id = request.form['request_id']

        # Delete the request from the "leave_requests" table
        c.execute('DELETE FROM leave_requests WHERE id=?', (request_id,))
        conn.commit()

    # Retrieve all leave requests from the "leave_requests" table
    c.execute('SELECT * FROM leave_requests')
    all_requests = c.fetchall()

    # Close the database connection
    conn.close()

    # Render the leave requests in an HTML table with a "Delete" button for each request
    return render_template('admin/all_requests.html', requests=all_requests)








# Route For Manage Salary
@app.route('/manage-salary')
def manage_salary():
    # Retrieve all salary records from the database
    conn = sqlite3.connect('test.db')
    c = conn.cursor()
    c.execute('SELECT * FROM salary')
    salaries = c.fetchall()
    conn.close()

    # Render the manage salary template with salary data
    return render_template('admin/manage_salary.html', salaries=salaries)


# Route For Logout
@app.route('/logout')
def user_logout():
    # perform any necessary logout actions here
    return redirect(url_for('index'))







@app.route("/signup", methods=["GET", "POST"])
def signup():
    if request.method == "POST":
        # Get form data
        username = request.form["username"]
        email = request.form["email"]
        password = request.form["password"]
        confirmpassword = request.form["confirmpassword"]
        # Validate email using validate_email library
        is_valid = validate_email(email)
        if is_valid:
        # Create a connection to the database
         conn = sqlite3.connect("test.db")
        # Create a cursor to execute SQL commands
         c = conn.cursor()
        # Create a table in the database if it doesn't already exist
         c.execute('''CREATE TABLE IF NOT EXISTS users (username TEXT, email TEXT, password TEXT, confirmpassword TEXT)''')
        
        try:
                # check if the username already exists
                c.execute("SELECT * FROM users WHERE username = ?", (username,))
                user = c.fetchone()
                if user:
                    return render_template("signup.html", error="Username already exists. Please try a different one.")
                # Insert the form data into the table
                c.execute("INSERT INTO users (username, email, password, confirmpassword) VALUES (?, ?, ?, ?)", (username, email, password, confirmpassword))
                # Commit the changes
                conn.commit()
        finally:
                # Close the connection
                conn.close()
        return redirect("/login")
    else:
            return render_template("signup.html", error="Invalid email address.")
    return render_template("signup.html")





@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        # Get form data
        username = request.form["username"]
        password = request.form["password"]

        # Connect to the database and check the user's credentials
        conn = sqlite3.connect("test.db")
        c = conn.cursor()
        c.execute("SELECT * FROM users WHERE username=? AND password=?", (username, password))

        # Fetch the result of the query
        result = c.fetchone()

        # Close the connection
        conn.close()

        # If the result is not None, the user's credentials are correct
        if result is not None:
            # Add the user's name to the session
            session["username"] = result[0]
            # Redirect the user to the welcome page
            return redirect("/")
        else:
            # The user's credentials are incorrect, render the login page with an error message
            return render_template("login.html", error="Incorrect username or password.")
    # If the request method is GET, render the login page
    return render_template("login.html")



@app.route("/check_username", methods=["POST"])
def check_username():
    # Get the username from the request
    username = request.form["username"]

    # Connect to the database
    conn = sqlite3.connect("test.db")
    c = conn.cursor()

    # Check if the username already exists in the database
    c.execute("SELECT * FROM users WHERE username = ?", (username,))
    result = c.fetchone()

    # Close the connection
    conn.close()

    # If the result is None, the username is available
    if result is None:
        return jsonify({"status": "available"})
    else:
        return jsonify({"status": "not available"})



if __name__ == "__main__":
    app.run(debug=True)
