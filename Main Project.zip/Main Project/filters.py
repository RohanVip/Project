from datetime import datetime

def format_date(value, format="%d/%m/%Y"):
    if isinstance(value, str):
        value = datetime.strptime(value, "%Y-%m-%d")
    return value.strftime(format)
