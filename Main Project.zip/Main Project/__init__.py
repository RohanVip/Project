

app = Flask(__name__)


# add your routes and other configuration here

if __name__ == '__main__':
    app.run(debug=True)
